#include <cpuinfo.h>


int main(int argc, char** argv) {
	cpuinfo_initialize();
	return 0;
}
